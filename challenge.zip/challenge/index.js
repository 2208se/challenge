const hambuger = document.querySelector(".hamburger");
const navList = document.querySelector(".nav-list");

if (hambuger) {
  hambuger.addEventListener("click", () => {
    navList.classList.toggle("open");
  });
}

const scrollContainer = document.querySelector('.scroll-container');

scrollContainer.addEventListener('wheel', (event) => {
  // Prevent vertical scrolling while allowing horizontal scrolling
  if (event.deltaY !== 0) {
    event.preventDefault();
    scrollContainer.scrollLeft += event.deltaY;
  }
});s